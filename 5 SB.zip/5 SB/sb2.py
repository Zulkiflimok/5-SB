# -*- coding: utf-8 -*-
#creator ZULKIFLI MOKOAGOW
#EDIT SESUKA KALIAN
from TEAM_TERMUX import *
#from BEAPI import BEAPI
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import ChatRoomAnnouncementContents
from akad.ttypes import ChatRoomAnnouncement
from thrift.unverting import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift import transport, protocol, server
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from akad.ttypes import IdentityProvider, LoginResultType, LoginRequest, LoginType
from gtts import gTTS
from bs4 import BeautifulSoup
from thrift import transport, protocol, server
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, random, multiprocessing, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib, urllib3, urllib.parse, html5lib, wikipedia, atexit, timeit, pafy, youtube_dl, traceback
from googletrans import Translator
from threading import Thread,Event
import wikipedia as wiki
from subprocess import check_output
from Naked.toolshed.shell import execute_js
import sys,traceback
import json, requests, LineService
from thrift.transport import THttpClient
from bs4.element import Tag
import requests as uReq
from datetime import datetime
from googletrans import Translator
from zalgo_text import zalgo
import ast, codecs, json, os, pytz, re, random, sys, time, urllib.parse, subprocess, threading, pyqrcode, pafy, humanize, os.path, traceback
from threading import Thread,Event
#import requests,uvloop
import wikipedia as wiki
from googletrans import Translator
import youtube_dl
requests.packages.urllib3.disable_warnings()
#loop = uvloop.new_event_loop()

admintart = time.time()

client = LINE("imel","paswor") #ganti imel sandi line kamu
client.log("Auth Token : " + str(client.authToken))
print ('_____________________')
print ('Untuk menggunakan fitur Template')
print ('Silahkan Copy link dibawah')
print('and Paste di line')
print ('_____________________')
print ('Click Link for Access Template :')
print ('line://app/1602687308-GXq4Vvk9?type=text&text=Success')
print ('_____________________')
user1 = client
cl = client
clientProfile = client.getProfile()
clientSettings = client.getSettings()
oepoll = OEPoll(client)
call = client
creator = ["u35d45deb4f87d0aa580fed5649a1df80","mid kamu"]
owner = ["u35d45deb4f87d0aa580fed5649a1df80","mid kamu"]
admin = ["u35d45deb4f87d0aa580fed5649a1df80","mid kamu"]
staff = ["u35d45deb4f87d0aa580fed5649a1df80","mid kamu"]
mid = client.getProfile().mid
zxcv = mid
unsend = []
welcome = []
msg_dict = {}
msg_dict1 = {}

dt_to_str = {}
temp_flood = {}
welcome = []

settings = {
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "postEndUrl": True,
    "likePost": False,
    "checkPost":True,
    "commentPost":True,
    "commentPost": "Autolike by ~ zul.1.01",
    "autoJoinTicket":True,
    "userMentioned": False,
    "SpamInvite":False,
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}

wait = {
    "limit": 1,
    "owner":{},
    "admin":{},
    "staff":{},
    "server": {},
    "Img": {},
    "Images": {},
    "addadmin":False,
    "delladmin":False,
    "addstaff":False,
    "dellstaff":False,
    "invite":False,
    "Spaminvite": {},
    "unsend": True,
    "blacklist":{},
    "contact":False,
    'autoJoin':True,
    'autoAdd':False,
    'autoRead':False,
    'autoLeave':False,
    "detectMention":True,
    "Mentionkick":False,
    "welcomeOn":False,
    "sidermem":False,
    "sticker":False,
    "selfbot":True,
    "mention": "NAH NGINTIP",
    "Respontag":"Gx usah tag' langsung transfer ajha ya",
    "welcome":"Selamat datang",
    "comment":"",
    "message":"hayo ketahuan add, mo ngapain  ,,",
    }

pro = {
    "prosider":{},
    "invitan":{},
    }

wait2 = {
    'readPoint':{},
    'readMember':{},
    'setTime':{},
    'ROM':{}
    }

ciduk = {
    'ceadPoint':{},
    'ceadMember':{},
    'cetTime':{},
    'cOM':{}
    }
data = {
    'info':{},
    'audio':{},
    "text":{},
    "image":{},
    "sticker":{},
}
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

mulai = time.time()

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)

def restart_program(): 
    python = sys.executable
    os.execl(python, python, * sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "Doorr ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["mention"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\nâââ[ {} ]".format(str(client.getGroup(to).name))
                except:
                    no = "\nâââ[ Success ]"
        client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        client.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def NoteCreate(to,cmd,msg):
	h = []
	s = []
	if cmd == 'tagnote':
		sakui = client.getProfile()
		group = client.getGroup(msg.to);nama = [contact.mid+'||//{}'.format(contact.displayName) for contact in group.members];nama.remove(sakui.mid+'||//{}'.format(sakui.displayName))
		data = nama
		k = len(data)//20
		for aa in range(k+1):
			nos = 0
			if aa == 0:dd = '╭─[ Mention Note ]';no=aa
			else:dd = '';no=aa*20
			msgas = dd
			for i in data[aa*20 : (aa+1)*20]:
				no+=1
				if no == len(data):msgas+='\n│{}. @  \n╰─[ by : zul.1.01 ]'.format(no)
				else:msgas+='\n│{}. @'.format(no)
			msgas = msgas
			for i in data[aa*20 : (aa+1)*20]:
				gg = []
				dd = ''
				for ss in msgas:
					if ss == '@':
						dd += str(ss)
						gg.append(dd.index('@'))
						dd = dd.replace('@',' ')
					else:
						dd += str(ss)
				s.append({'type': "RECALL", 'start': gg[nos], 'end': gg[nos]+1, 'mid': str(i.split('||//')[0])})
				nos +=1
			h = client.createPostGroup(msgas,msg.to,holdingTime=None,textMeta=s)
			
def sendTemplate(group, data):
    xyz = LiffChatContext(group)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "Total Member Masuk「{}」\nHaii  ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = client.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["welcome"]+"\nNama grup : "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(client.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        client.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def mentionMembers(to, mid):
    try:
        arrData = ""
        textx = "Total User「{}」\n\n1. ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(client.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        client.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention(to, mid, firstmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x \n"
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        today = datetime.today()
        future = datetime(2018,3,1)
        hari = (str(future - today))
        comma = hari.find(",")
        hari = hari[:comma]
        teman = cl.getAllContactIds()
        gid = cl.getGroupIdsJoined()
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        eltime = time.time() - mulai
        bot = runtime(eltime)
        text += mention+"jam : "+datetime.strftime(timeNow,'%H:%M:%S')+" wib\nNama Group : "+str(len(gid))+"\nTeman : "+str(len(teman))+"\nExpired : In "+hari+"\n Version :「Gaje Bots」  \nTanggal : "+datetime.strftime(timeNow,'%Y-%m-%d')+"\nRuntime : \n • "+bot
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendAudioWithURL(self, to_, url):
        path = self.downloadFileWithURL(url)
        try:
            self.sendAudio(to_, path)
        except Exception as e:
            raise Exception(e)

def sendAudioWithUrl(self, to_, url):
        path = '%s/pythonLine-%1.data' % (tempfile.gettempdir(), randint(0, 9))
        r = requests.get(url, stream=True, verify=False)
        if r.status_code == 200:
           with open(path, 'w') as f:
              shutil.copyfileobj(r.raw, f)
        else:
           raise Exception('Download audio failure.')
        try:
            self.sendAudio(to_, path)
        except Exception as e:
            raise e

def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        import urllib,request
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"
            
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
    
def sendImage(to, path, name="image"):
    try:
        if settings["server"] == "VPS":
            client.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)

def sendTemplates(to, data):
    data = data
    url = "https://api.line.me/message/v3/share"
    headers = {}
    headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 8.1.0; Redmi Note 5 Build/OPM1.171019.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/67.0.3396.87 Mobile Safari/537.36 Line/8.1.1'  
    headers['Content-Type'] = 'application/json'  
    headers['Authorization'] = 'Bearer eyJhbGciOiJIUzI1NiJ9.5uMcEEHahauPb5_MKAArvGzEP8dFOeVQeaMEUSjtlvMV9uuGpj827IGArKqVJhiGJy4vs8lkkseiNd-3lqST14THW-SlwGkIRZOrruV4genyXbiEEqZHfoztZbi5kTp9NFf2cxSxPt8YBUW1udeqKu2uRCApqJKzQFfYu3cveyk.GoRKUnfzfj7P2uAX9vYQf9WzVZi8MFcmJk8uFrLtTqU'
    sendPost = requests.post(url, data=json.dumps(data), headers=headers)
    print(sendPost)
    return sendPost

def sendflex(to, data):
    n1 = LiffChatContext(to)
    n2 = LiffContext(chat=n1)
    view = LiffViewRequest('1602687308-GXq4Vvk9', n2)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

uagent = {
    "User-Agent": "Mozilla\t5.0"
}

def rynSplitText(text,lp=''):
    separate = text.split(" ")
    if lp == '':
        adalah = text.replace(separate[0]+" ","")
    elif lp == 's':
        adalah = text.replace(separate[0]+" "+separate[1]+" ","")
    else:
        adalah = text.replace(separate[0]+" "+separate[1]+" "+separate[2]+" ","")
    return adalah

def urlEncode(url):
  import base64
  return base64.b64encode(url.encode()).decode('utf-8')

def urlDecode(url):
  import base64
  return base64.b64decode(url.encode()).decode('utf-8')

def removeCmdv(text, key=""):
    setKey = key
    text_ = text[len(setKey):]
    sep = text_.split(" ")
    return text_.replace(sep[0] + " ", "")

def removeCmd(cmd, text):
    key = settings["keyCommand"]
    if settings["setKey"] == False: key = ''
    rmv = len(key + cmd) + 1
    return text[rmv:]

def multiCommand(cmd, list_cmd=[]):
    if True in [cmd.startswith(c) for c in list_cmd]:
        return True
    else:
        return False

def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
    
def GenPictureQRCode(to,url):
    fn=url+".png"
    wildan=pyqrcode.create(url)
    wildan.png(fn, scale=6, module_color=[0, 0, 0, 128], background="#FFFFFF")
    wildan.show()
    client.sendImage(to,fn)
    os.remove(fn)

def uploadFile(ryn):
    url = 'https://fahminogameno.life/uploadimage/action.php'
    path = client.downloadFileURL('https://obs-sg.line-apps.com/talk/m/download.nhn?oid='+ryn, 'path','ryngenerate.png')
    data = {'register':'submit'}
    files = {"file": open(path,'rb')}
    r = requests.post(url, data=data, files=files)
    if r.status_code == 200:
        return path

def google_url_shorten(url):
    req_url = 'https://www.googleapis.com/urlshortener/v1/url?key=AIzaSyAzrJV41pMMDFUVPU0wRLtxlbEU-UkHMcI'
    payload = {'longUrl': url}
    headers = {'content-type': 'application/json'}
    r = requests.post(req_url, data=json.dumps(payload), headers=headers)
    resp = json.loads(r.text)
    #return resp['id'].replace("https://","")

def generateLink(to, ryn, rynurl=None):
    path = client.downloadFileURL('https://obs-sg.line-apps.com/talk/m/download.nhn?oid='+ryn, 'path','ryngenerate.jpg')
    data = {'register':'submit'}
    files = {"file": open(path,'rb')}
    url = 'https://fahminogameno.life/uploadimage/action.php'
    r = requests.post(url, data=data, files=files)
    client.sendMessage(to, '%s\n%s' % (r.status_code,r.text))
    client.sendMessage(to, '{}{}'.format(rynurl,urlEncode('https://fahminogameno.life/uploadimage/images/ryngenerate.png')))

def uploadFile(ryn):
    url = 'https://fahminogameno.life/uploadimage/action.php'
    path = client.downloadFileURL('https://obs-sg.line-apps.com/talk/m/download.nhn?oid='+ryn, 'path','ryngenerate.png')
    data = {'register':'submit'}
    files = {"file": open(path,'rb')}
    r = requests.post(url, data=data, files=files)
    if r.status_code == 200:
        return path

def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

#delete log if pass more than 90 hours
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]

def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")

def backupProfile():
    profile = client.getContact(mid)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    settings['myProfile']['videoProfile'] = profile.videoProfile
    coverId = client.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)
	
def restoreProfile():
    profile = client.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = client.downloadFileURL("http://dl.profile.line-cdn.net/{}".format(settings["myProfile"]["pictureStatus"]), saveAs="tmp/backupPicture.bin")
        client.updateProfilePicture(profile.pictureStatus)
        client.updateProfile(profile)
    else:
        client.updateProfile(profile)
        pict = client.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = client.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    client.updateProfileCoverById(coverId)
	
def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.1)        
            page = page[end_content:]
    return items
    
def backupData():
    try:
        backup1 = Setmain
        f = codecs.open('setting.json','w','utf-8')
        json.dump(backup1, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup2 = settings
        f = codecs.open('settings.json','w','utf-8')
        json.dump(backup2, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup3 = wait
        f = codecs.open('wait.json','w','utf-8')
        json.dump(backup3, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup4 = read
        f = codecs.open('read.json','w','utf-8')
        json.dump(backup4, f, sort_keys=True, indent=4, ensure_ascii=False)        
        return True
    except Exception as error:
        logError(error)
        return False     

def restartBot():
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
     
def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def YoutubeTempat(wait,to,meta,dfghj,links,linkss):
    return {"messages": [{"type": "flex","altText": "Youtube","contents": {"type": "bubble","header": {"type": "box","layout": "horizontal","contents": [{"type": "text","text": "Youtube","weight": "bold","color": "#9b0606","size": "sm"}]},"hero": {"type": "image","url": meta['thumbnail'],"size": "full","aspectRatio": "20:13","aspectMode": "cover","action": {"type": "uri","uri": dfghj}},"body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Title","color": "#9b0606","size": "sm","flex": 1},{"type": "text","text": "{}".format(meta['title']),"color": "#262423","wrap": True,"size": "sm","flex": 5}]}]}]},"footer": {"type": "box","layout": "horizontal","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "กดเพื่อดูวีดีโอ","uri": "line://app/1602687308-GXq4Vvk9?type=video&ocu={}&piu={}".format(links,meta['thumbnail'])}},{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "กดเพื่อฟังเสียง","uri": "line://app/1602687308-GXq4Vvk9?type=audio&link={}".format(linkss)}}],"flex": 0}}}]}

def executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey):
    if cmd.startswith('ex\n'):
      if sender in clientMid:
        try:
            sep = text.split('\n')
            ryn = text.replace(sep[0] + '\n','')
            f = open('exec.txt', 'w')
            sys.stdout = f
            print(' ')
            exec(ryn)
            print('\n%s' % str(datetime.now()))
            f.close()
            sys.stdout = sys.__stdout__
            with open('exec.txt','r') as r:
                txt = r.read()
            client.sendMessage(to, txt)
        except Exception as e:
            pass
      else:
        client.sendMessage(to, 'what !')
    elif cmd.startswith('exc\n'):
      if sender in clientMid:
        sep = text.split('\n')
        ryn = text.replace(sep[0] + '\n','')
        if 'print' in ryn:
        	ryn = ryn.replace('print(','client.sendExecMessage(to,')
        	exec(ryn)
        else:
        	exec(ryn)
      else:
        client.sendMessage(to, 'what !')

def logError(text):
    client.log("[ INFO ] ERROR : " + str(text))
    time_ = datetime.now()
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time_), text))
		
def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = client.genOBSParams({'oid': mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = client.server.postContent('{}/talk/vp/upload.nhn'.format(str(client.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        client.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))

def sendMessage(self, messageObject):
        return self.Talk.client.sendMessage(0,messageObject)

def RECEIVE_MESSAGE(op):
    msg = op.message
    text = msg.text
    msg_id = msg.id
    receiver = msg.to
    sender = msg._from
    try:
        if msg.contentType == 0:
            try:
                if msg.to in wait2['readPoint']:
                    if msg._from in wait2["ROM"][msg.to]:
                        del wait2["ROM"][msg.to][msg._from]
                else:
                    pass
            except:
                pass
        else:
            pass
    except KeyboardInterrupt:
                sys.exit(0)
    except Exception as error:
        print (error)
        print ("\n\nRECEIVE_MESSAGE\n\n")
        return

def delExpire():
    if temp_flood != {}:
        for tmp in temp_flood:
            if temp_flood[tmp]["expire"] == True:
                if time.time() - temp_flood[tmp]["time"] >= 3*10:
                    temp_flood[tmp]["expire"] = False
                    temp_flood[tmp]["time"] = time.time()
                    try:
                        userid = "https://line.me/ti/p/~" + client.profile.userid
                        client.sendFooter(tmp, "Self Active again", str(userid), "http://dl.profile.line-cdn.net/"+client.getContact(mid).pictureStatus, client.getContact(mid).displayName)
                        veza = "「BOT ACTIVE AGAIN」"
                        client.sendMessage(tmp, veza, {'AGENT_LINK': "https://line.me/ti/p/~mobaloghanabi", 'AGENT_ICON': "http://klikuntung.com/images/messengers/line-logo.png", 'AGENT_NAME': "Detect Spam "})        
                    except Exception as error:
                        logError(error)

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd
    
listCarousel = """
                                             \n
                                             \n
* .Me                                   \n
* Absen                              \n
* Ok                                     \n
* Kabur                               \n
* Amin                                \n
* Mf                                     \n
* Wkwk                               \n
* Haha                                \n
* Siap                                  \n
* Assalamualaikum        \n
* Waalaikumsalam         \n
"""
help = """
                                             \n
                                             \n
* .run (server)                   \n
* Login liff                          \n
* Menu Self                       \n
* Menu Admin                  \n
* Tagnote                          \n
* Media                              \n
* Carousel                         \n
"""
menuSelf = """
                                               \n
                                               \n
* Me                                      \n
* Mid                                     \n
* Status                               \n
* Tagall                                \n
* Footer    「 text 」         \n
* Flex         「 text 」         \n
* Mid「@」                        \n
* Unsend「On/Off」        \n
* Respon「On/Off」        \n
* Sider「On/Off」             \n
* Welcome「On/Off」     \n
* Left「On/Off」               \n
* Sticker「On/Off」         \n
* Respon「On/Off」         \n
* Contact「On/Off」        \n
* Autojoin「On/Off」        \n
* Autoadd「On/Off」        \n
* Welcome 「On/Off」     \n
* Autoleave  「On/Off」   \n
"""

menuAdmin = """
                                                   \n
                                                   \n
* Admin:on                              \n
* Admin:repeat                      \n
* Staff:on                                 \n
* Staff:repeat                         \n
* Refresh                                 \n
* Listadmin                             \n
* Restart                                 \n
* Runtime                               \n
* Tendang「@」                  \n
* Blc                                         \n
* Open                                     \n
* Close                                    \n
* Url grup                                \n
* Banlist                                  \n
* Clearban                              \n
* Staffadd    「@」              \n
* Staffdell     「@」             \n
* Adminadd 「@」              \n
* Admindell  「@」              \n
* Kickall                                   \n
"""
media = """
                                                   \n
                                                   \n
* Grouplist                               \n
* Lurking「On/Off」            \n
* Lurkers                                  \n
* UpdateFoto                          \n
* UpdateGroup                       \n
* Bcast「On/Off」                \n
* Musik:「On/Off」               \n
* Youtube:「On/Off」          \n
* Spamtag「@」                   \n
* SpamCall「 Jumlah 」      \n
* SpamInvite                            \n
* Jumlah:「On/Off」             \n
* Spam:「Mid/Jumlah」      \n
"""
order = """
                                                      \n
                                                      \n
* Sb + assist                               \n
* Sb template                            \n
* Bot Protect                             \n
* Bot CL                                      \n
* Bot War                                    \n
* Login Kickall/Ticket             \n
* Dll.                                             \n
* W.a/ 6281356364708           \n
"""
def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        if op.type == 13:
            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in admin:
                        client.acceptGroupInvitation(op.param1)
                        ginfo = client.getGroup(op.param1)
                        client.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        client.leaveGroup(op.param1)
                    else:
                        client.acceptGroupInvitation(op.param1)
                        ginfo = client.getGroup(op.param1)
                        client.sendMessage(op.param1,"Hai " + str(ginfo.name))

        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in admin:
                        client.acceptGroupInvitation(op.param1)
                        ginfo = client.getGroup(op.param1)
                        client.sendMessage(op.param1,"Assalamualaikum")
                    else:
                        client.acceptGroupInvitation(op.param1)
                        ginfo = client.getGroup(op.param1)
                        client.sendMessage(op.param1,"Assalamualaikum")
        if op.type == 17:
            if op.param1 in welcome:
                if op.param2 in admin:
                    pass
                ginfo = client.getGroup(op.param1)
                contact = client.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                welcomeMembers(op.param1, [op.param2])
                client.sendImageWithURL(op.param1, image)

        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in admin:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        client.sendMessage(op.param1, wait["message"])

                return

        if op.type == 55:
            try:
                if op.param1 in Setmain["ARreadPoint"]:
                   if op.param2 in Setmain["ARreadMember"][op.param1]:
                       pass
                   else:
                       Setmain["ARreadMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass

        if op.type == 55:
            msg = op.message
            if op.param1 in pro["prosider"]:
                if op.param1 in ciduk['ceadPoint']:
                    x = client.getContact(op.param2)
                    x_name = x.displayName
                    if x_name not in ciduk['ceadMember'][op.param1]:
                        ciduk['ceadMember'][op.param1] += x_name
                        ciduk['cOM'][op.param1][op.param2] = x_name
                        contact = client.getContact(op.param2)
                        data = {"type": "flex","altText": "{} Bagi2 Sembako".format(client.getContact(mid).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(x_name),"color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "  ❄    CCTV    ➣","color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(op.param2).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                        sendTemplate(op.param1, data)
                        
        if op.type == 65:
            if wait["unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'Gambarnya dibawah':
                                ginfo = client.getGroup(at)
                                ryan = client.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "「 Gambar Dihapus 」\n• Pengirim : "
                                ret_ = "• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ry = str(ryan.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                client.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                client.sendImage(at, msg_dict[msg_id]["data"])
                           else:
                                ginfo = client.getGroup(at)
                                ryan = client.getContact(msg_dict[msg_id]["from"])
                                ret_ =  "「 Pesan Dihapus 」\n"
                                ret_ += "• Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\n• Pesannya : {}".format(str(msg_dict[msg_id]["text"]))
                                client.sendMessage(at, str(ret_))
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 65:
            if wait["unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = client.getGroup(at)
                                ryan = client.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "「 Sticker Dihapus 」\n"
                                ret_ += "• Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                client.sendMessage(at, str(ret_))
                                client.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)
#===================

        if op.type == 25 or op.type == 26:
          if settings['SpamInvite'] == True:
            msg = op.message
            sender = msg._from
            receiver = msg.to
            if msg.contentType == 13:
                if op.param2 not in admin:
                    korban = msg.contentMetadata["displayName"]
                    invite = msg.contentMetadata[target]
                    groups = client.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for x in groups.members:
                        if korban in x.displayName:
                            client.sendMessage(msg.to, korban + " Sudah Berada DiGrup Ini")
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                        for target in targets:
                            try:
                                client.findAndAddContactsByMid(target)                                
                                client.createGroup("Test", [target])
                                client.createGroup("Test", [target])  
                                client.createGroup("Test", [target])                            
                                client.createGroup("Test", [target])                          
                                client.createGroup("Test", [target])
                                client.createGroup("Test", [target])  
                                client.createGroup("Test", [target])  
                                client.createGroup("Test", [target])  
                                client.createGroup("Test", [target])  
                                client.sendMessage(msg.to, "Spam Invite ke " + korban + "\nSUCCESS..")
                                settings['SpamInvite'] = False
                            except:             
                                 client.sendMessage(msg.to, 'Contact error')
                                 settings['SpamInvite'] = False
                                 break

        if op.type == 25 or op.type == 26:
         if wait["selfbot"] == True:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != client.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if wait["unsend"] == True:
                    try:
                        msg = op.message
                        if msg.toType == 0:
                            client.log("[{} : {}]".format(str(msg._from), str(msg.text)))
                        else:
                            client.log("[{} : {}]".format(str(msg.to), str(msg.text)))
                            msg_dict[msg.id] = {"text": msg.text, "from": msg._from, "createdTime": msg.createdTime, "contentType": msg.contentType, "contentMetadata": msg.contentMetadata}
                    except Exception as error:
                        logError(error)
                    if msg.contentType == 1:
                        if wait["unsend"] == True:
                            try:
                                path = client.downloadObjectMsg(msg_id)
                                msg_dict[msg.id] = {"text":'Gambarnya dibawah',"data":path,"from":msg._from,"createdTime":msg.createdTime}
                            except Exception as error:
                                logError(error)
        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in admin:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          client.kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              client.kickoutFromGroup(msg.to, [msg._from])
                          except:
                              client.kickoutFromGroup(msg.to, [msg._from])
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in admin:
                           ca = client.getContact(sender)
                           ca = client.getProfileCoverURL(sender)
                           image = str(ca)
                           group = client.getGroupIdsJoined()
                           contact = client.getProfile()
                           mids = [contact.mid]
                           msg.contentType = 13
                           status = client.getContact(sender)
                           status2 = client.getContact(mid)
                           msg.contentMetadata = {'mid': msg._from}
                           data = ({"type":"flex","altText":"Flex Message","contents":{"contents":[{"styles":{"body":{"backgroundColor":"#000000"},"footer":{"backgroundColor":"#ff0000"}},"type":"bubble","size":"micro","body":{"contents":[{"contents":[{"type":"separator","color":"#ff0000"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"text":"Profile","size":"xxs","align":"center","color":"#ffffff","wrap":True,"weight":"bold","type":"text"}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"type":"image","url":"https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"size":"full","aspectMode":"cover","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"flex":0}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"text":"❂  {}  ➣".format(status.displayName),"size":"xxs","align":"center","color":"#ffffff","wrap":True,"weight":"bold","type":"text"}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"type":"image","url":"https://i.ibb.co/4N1BjnV/20190427-175005.png","size":"xl","action":{"type":"uri","uri":"https://wa.me/62895636724315"},"flex":1},{"type":"image","url":"https://i.ibb.co/b53ztTR/20190427-191019.png","size":"xl","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"flex":1},{"type":"image","url":"https://i.ibb.co/ZHtFDts/20190427-185307.png","size":"xl","action":{"type":"uri","uri":"line://nv/chat"},"flex":1},{"type":"image","url":"https://i.ibb.co/CntKh4x/20190525-152240.png","size":"xl","action":{"type":"uri","uri":"Https://smule.com/SMI_AFRIZAL"},"flex":1},{"type":"image","url":"https://i.ibb.co/8YfQVtr/20190427-185626.png","size":"xl","action":{"type":"uri","uri":"line://call/contacts"},"flex":1},{"contents":[{"type":"image","url":"https://i.ibb.co/kSMSnWn/20190427-191235.png","size":"xl","action":{"type":"uri","uri":"line://nv/camera/"},"flex":1}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"vertical"}],"type":"box","spacing":"xs","layout":"vertical"},"footer":{"type":"box","layout":"horizontal","contents":[{"type":"text","text":"Creator","size":"xxs","wrap":True,"weight":"bold","color":"#ffffff","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"align":"center"}]}},{"styles":{"body":{"backgroundColor":"#000000"},"footer":{"backgroundColor":"#ff0000"}},"type":"bubble","size":"micro","body":{"contents":[{"contents":[{"type":"separator","color":"#ff0000"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"text":"Cover","size":"xxs","align":"center","color":"#ffffff","wrap":True,"weight":"bold","type":"text"}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"type":"image","url":"{}".format(ca),"size":"full","aspectMode":"cover","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"flex":0}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"text":"Respon tag ,, ","size":"xxs","align":"center","color":"#ffffff","wrap":True,"weight":"bold","type":"text"}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"type":"image","url":"https://i.ibb.co/XWQd8rj/20190625-201419.png","size":"xl","action":{"type":"uri","uri":"https://youtube.com"},"flex":1},{"type":"image","url":"https://i.ibb.co/1sGhJdC/20190428-232658.png","size":"xl","action":{"type":"uri","uri":"line://nv/timeline"},"flex":1},{"type":"image","url":"https://i.ibb.co/Wf8bQ2Z/20190625-105354.png","size":"xl","action":{"type":"uri","uri":"line://nv/cameraRoll/multi"},"flex":1},{"type":"image","url":"https://i.ibb.co/fxWzxcR/20190428-232352.png","size":"xl","action":{"type":"uri","uri":"line://nv/settings"},"flex":1},{"type":"image","url":"https://i.ibb.co/cb7WqMS/20190428-232825.png","size":"xl","action":{"type":"uri","uri":"line://nv/profile"},"flex":1},{"contents":[{"type":"image","url":"https://i.ibb.co/7YVnNPF/20190625-190410.png","size":"xl","action":{"type":"uri","uri":"https://joox.com"},"flex":1}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#33ffff"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"vertical"}],"type":"box","spacing":"xs","layout":"vertical"},"footer":{"type":"box","layout":"horizontal","contents":[{"type":"text","text":"Creator","size":"xxs","wrap":True,"weight":"bold","color":"#ffffff","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"align":"center"}]}},{"styles":{"body":{"backgroundColor":"#000000"},"footer":{"backgroundColor":"#ff0000"}},"type":"bubble","size":"micro","body":{"contents":[{"contents":[{"type":"separator","color":"#ff0000"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"text":"My profile","size":"xxs","align":"center","color":"#ffffff","wrap":True,"weight":"bold","type":"text"}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"type":"image","url":"https://obs.line-scdn.net/{}".format(client.getContact(mid).pictureStatus),"size":"full","aspectMode":"cover","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"flex":0}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"text":"❂  𝕬𝖋𝖗𝖎𝖟𝖆𝖑  ➣","size":"xxs","align":"center","color":"#ffffff","wrap":True,"weight":"bold","type":"text"}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"type":"image","url":"https://i.ibb.co/XWQd8rj/20190625-201419.png","size":"xl","action":{"type":"uri","uri":"https://youtube.com"},"flex":1},{"type":"image","url":"https://i.ibb.co/1sGhJdC/20190428-232658.png","size":"xl","action":{"type":"uri","uri":"line://nv/timeline"},"flex":1},{"type":"image","url":"https://i.ibb.co/Wf8bQ2Z/20190625-105354.png","size":"xl","action":{"type":"uri","uri":"line://nv/cameraRoll/multi"},"flex":1},{"type":"image","url":"https://i.ibb.co/fxWzxcR/20190428-232352.png","size":"xl","action":{"type":"uri","uri":"line://nv/settings"},"flex":1},{"type":"image","url":"https://i.ibb.co/cb7WqMS/20190428-232825.png","size":"xl","action":{"type":"uri","uri":"line://nv/profile"},"flex":1},{"contents":[{"type":"image","url":"https://i.ibb.co/7YVnNPF/20190625-190410.png","size":"xl","action":{"type":"uri","uri":"https://joox.com"},"flex":1}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"vertical"}],"type":"box","spacing":"xs","layout":"vertical"},"footer":{"type":"box","layout":"horizontal","contents":[{"type":"text","text":"Creator","size":"xxs","wrap":True,"weight":"bold","color":"#ffffff","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"align":"center"}]}}],"type":"carousel"}})
                           sendflex(to, data)
                           break
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in admin:
                           client.mentiontag(msg.to,[msg._from])
                           client.sendMessage(msg.to, "Jangan tag saya....")
                           client.kickoutFromGroup(msg.to, [msg._from])
                           break
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    client.sendMessage(msg.to,"「Cek ID Sticker」\n❧STKID : " + msg.contentMetadata["STKID"] + "\n❧STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n❧STKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    client.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = client.getContact(msg.contentMetadata["mid"])
                        path = client.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        client.sendMessage(msg.to,"❧Nama : " + msg.contentMetadata["displayName"] + "\n❧MID : " + msg.contentMetadata["mid"] + "\n❧Status Msg : " + contact.statusMessage + "\n❧Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        client.sendImageWithURL(msg.to, image)

        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
               if msg.toType == 0:
                   if sender != client.profile.mid:
                       to = sender
                   else:
                       to = receiver
               elif msg.toType == 1:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    client.sendMessage(msg.to,"STKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    client.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = client.getContact(msg.contentMetadata["mid"])
                        path = client.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        client.sendMessage(msg.to,"❧Nama : " + msg.contentMetadata["displayName"] + "\n❧MID : " + msg.contentMetadata["mid"] + "\n❧Status Msg : " + contact.statusMessage + "\n❧Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        client.sendImageWithURL(msg.to, image)
               if msg.contentType == 13:
                if msg._from in admin:
                  if wait["invite"] == True:
                    msg.contentType = 0
                    contact = client.getContact(msg.contentMetadata["mid"])
                    invite = msg.contentMetadata["mid"]
                    groups = client.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if invite in wait["blacklist"]:
                            client.sendMessage(msg.to, "Maaf, dia ada di daftar blacklist\n")
                            break
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                         for target in targets:
                             try:
                                  client.findAndAddContactsByMid(target)
                                  client.inviteIntoGroup(msg.to,[target])
                                  ryan = client.getContact(target)
                                  zx = ""
                                  zxc = ""
                                  zx2 = []
                                  xpesan =  "「 Sukses Invite 」\nNama "
                                  ret_ = "Ketik invite off jika sudah masuk"
                                  ry = str(ryan.displayName)
                                  pesan = ''
                                  pesan2 = pesan+"@x\n"
                                  xlen = str(len(zxc)+len(xpesan))
                                  xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                  zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                  zx2.append(zx)
                                  zxc += pesan2
                                  text = xpesan + zxc + ret_ + ""
                                  client.sendReplyMessage(msg.id,msg.to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                  wait["invite"] = False
                                  break
                             except:
                                  client.sendMessage(msg.to,"ʏᴏᴜʀ ᴀᴄᴄᴏᴜɴᴛ ʟɪᴍɪᴛ")
                                  wait["invite"] = False
                                  break
               if msg.contentType == 16:
                            if settings["checkPost"] == True:
                                try:
                                    ret_ = "╔══[ Details Post ]"
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        contact = client.getContact(sender)
                                        auth = "\n├≽ Penulis : {}".format(str(contact.displayName))
                                    else:
                                        auth = "\n├≽ Penulis : {}".format(str(msg.contentMetadata["serviceName"]))
                                    purl = "\n├≽ URL : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                                    ret_ += auth
                                    ret_ += purl
                                    if "mediaOid" in msg.contentMetadata:
                                        object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                                        if msg.contentMetadata["mediaType"] == "V":
                                            if msg.contentMetadata["serviceType"] == "GB":
                                                ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                                murl = "\n├≽ Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                                            else:
                                                ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                                murl = "\n├≽ Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                                            ret_ += murl
                                        else:
                                            if msg.contentMetadata["serviceType"] == "GB":
                                                ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                            else:
                                                ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                        ret_ += ourl
                                    if "stickerId" in msg.contentMetadata:
                                        stck = "\n├≽ Stiker : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                                        ret_ += stck
                                    if "text" in msg.contentMetadata:
                                        text = "\n├≽ Tulisan : {}".format(str(msg.contentMetadata["text"]))
                                        ret_ += text
                                    ret_ += "\n╚══[ Finish ]"
                                    client.sendMessage(to, str(ret_))
                                except:
                                    client.sendMessage(to, "Post tidak valid")
                            if msg.contentType == 16:
                                purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                                adw = client.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                                adws = client.createComment(purl[0], purl[1], settings["commentPost"])
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Success Like & Command","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

               if msg.contentType == 0:
                   if "haha" in msg.text.lower():
                          url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                          to = msg.to
                          data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(client.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/xHDXBrd/AW316783-23.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://line.me/ti/p/~zul.1.01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                          client.postTemplate(to, data)
                   elif "wkwk" in msg.text.lower():
                          url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                          to = msg.to
                          data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(client.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.pinimg.com/originals/9e/bb/f7/9ebbf7a320a06fb9a254b2f521bbd4ec.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://line.me/ti/p/~zul.1.01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                          sendTemplate(to, data) 
                   if "amin" in msg.text.lower():
                          url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                          to = msg.to
                          data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(client.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.pinimg.com/originals/c5/1d/da/c51ddaae928617f00f962eb96fd4af33.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://line.me/ti/p/~zul.1.01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                          sendTemplate(to, data) 
                   if "kabur" in msg.text.lower():
                          url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                          to = msg.to
                          data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(client.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/FsTqdpd/fac502b083ab70051050890b99bb6e73.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://line.me/ti/p/~zul.1.01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                          sendTemplate(to, data) 
                   if "siap" in msg.text.lower():
                          url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                          to = msg.to
                          data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(client.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/TKZ2KVD/AW316783-09.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://line.me/ti/p/~zul.1.01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                          sendTemplate(to, data) 
                   if "mf" in msg.text.lower():
                          url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                          to = msg.to
                          data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(client.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/LJXgPb2/AW316783-21.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://line.me/ti/p/~zul.1.01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                          sendTemplate(to, data) 
                   if "ok" in msg.text.lower():
                          url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                          to = msg.to
                          data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(client.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/wYxLwRL/AW316783-02.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://line.me/ti/p/~zul.1.01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                          sendTemplate(to, data) 
                   elif "assalamualaikum" in msg.text.lower():
                          url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                          to = msg.to
                          data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(client.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/cgXn5dL/AW1575362-01.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://line.me/ti/p/~zul.1.01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                          sendTemplate(to, data) 
                   elif "waalaikumsalam" in msg.text.lower():
                          url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                          to = msg.to
                          data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(client.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/cgXn5dL/AW1575362-01.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://line.me/ti/p/~zul.1.01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                          sendTemplate(to, data) 
                   if "absen" in msg.text.lower():
                          url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                          to = msg.to
                          data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(client.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/Rytk8fV/AW316783-08.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://line.me/ti/p/~zul.1.01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                          sendTemplate(to, data) 
                   if ".me" in msg.text.lower():
                          url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
                          to = msg.to
                          data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(client.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "https://i.ibb.co/QJmnqjK/AW316783-13.gif",
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://line.me/ti/p/~zul.1.01"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                          sendTemplate(to, data) 
                   elif text.lower() == "aslkm":
                          contact = client.getContact(sender)
                          data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Waalaikumsalam","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                          sendTemplate(to, data)
                   elif text.lower() == "mid":
                          contact = client.getContact(sender)
                          client.sendMessage(msg.to, msg._from)
                   elif text.lower() == "order":
                          contact = client.getContact(sender)
                          data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "text","text":"{}".format(order),"size":"xxs","align":"center","color":"#0000CC","wrap":True,},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "OPEN ORDER","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "  ❄  AULIA ➣","color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                          sendTemplate(to, data)
                   elif text.lower() == "creator":
                          contact = client.getContact(sender)
                          status = client.getContact(mid)
                          data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "CREATOR BOTS","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(mid).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(mid).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                          sendTemplate(to, data)

                   elif text.lower() == 'me':
                           msg.contentType = 13
                           status = client.getContact(sender)
                           cu = client.getProfileCoverURL(sender)
                           image = str(cu)
                           status2 = client.getContact(mid)
                           msg.contentMetadata = {'mid': msg._from}
                           data = ({"type":"flex","altText":"Flex Message","contents":{"contents":[{"styles":{"body":{"backgroundColor":"#000000"},"footer":{"backgroundColor":"#ff0000"}},"type":"bubble","size":"micro","body":{"contents":[{"contents":[{"type":"separator","color":"#ff0000"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"text":"Profile","size":"xxs","align":"center","color":"#ffffff","wrap":True,"weight":"bold","type":"text"}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"type":"image","url":"https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"size":"full","aspectMode":"cover","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"flex":0}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"text":"{}".format(status.displayName),"size":"xxs","align":"center","color":"#ffffff","wrap":True,"weight":"bold","type":"text"}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"type":"image","url":"https://i.ibb.co/4N1BjnV/20190427-175005.png","size":"xl","action":{"type":"uri","uri":"https://wa.me/62895636724315"},"flex":1},{"type":"image","url":"https://i.ibb.co/b53ztTR/20190427-191019.png","size":"xl","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"flex":1},{"type":"image","url":"https://i.ibb.co/ZHtFDts/20190427-185307.png","size":"xl","action":{"type":"uri","uri":"line://nv/chat"},"flex":1},{"type":"image","url":"https://i.ibb.co/CntKh4x/20190525-152240.png","size":"xl","action":{"type":"uri","uri":"Https://smule.com/SMI_afrizal88"},"flex":1},{"type":"image","url":"https://i.ibb.co/8YfQVtr/20190427-185626.png","size":"xl","action":{"type":"uri","uri":"line://call/contacts"},"flex":1},{"contents":[{"type":"image","url":"https://i.ibb.co/kSMSnWn/20190427-191235.png","size":"xl","action":{"type":"uri","uri":"line://nv/camera/"},"flex":1}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"vertical"}],"type":"box","spacing":"xs","layout":"vertical"},"footer":{"type":"box","layout":"horizontal","contents":[{"type":"text","text":"Creator","size":"xxs","wrap":True,"weight":"bold","color":"#ffffff","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"align":"center"}]}},{"styles":{"body":{"backgroundColor":"#000000"},"footer":{"backgroundColor":"#ff0000"}},"type":"bubble","size":"micro","body":{"contents":[{"contents":[{"type":"separator","color":"#ff0000"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"text":"Cover","size":"xxs","align":"center","color":"#ffffff","wrap":True,"weight":"bold","type":"text"}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"type":"image","url":"{}".format(cu),"size":"full","aspectMode":"cover","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"flex":0}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"text":"{}".format(status.displayName),"size":"xxs","align":"center","color":"#ffffff","wrap":True,"weight":"bold","type":"text"}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"type":"image","url":"https://i.ibb.co/XWQd8rj/20190625-201419.png","size":"xl","action":{"type":"uri","uri":"https://youtube.com"},"flex":1},{"type":"image","url":"https://i.ibb.co/1sGhJdC/20190428-232658.png","size":"xl","action":{"type":"uri","uri":"line://nv/timeline"},"flex":1},{"type":"image","url":"https://i.ibb.co/Wf8bQ2Z/20190625-105354.png","size":"xl","action":{"type":"uri","uri":"line://nv/cameraRoll/multi"},"flex":1},{"type":"image","url":"https://i.ibb.co/fxWzxcR/20190428-232352.png","size":"xl","action":{"type":"uri","uri":"line://nv/settings"},"flex":1},{"type":"image","url":"https://i.ibb.co/cb7WqMS/20190428-232825.png","size":"xl","action":{"type":"uri","uri":"line://nv/profile"},"flex":1},{"contents":[{"type":"image","url":"https://i.ibb.co/7YVnNPF/20190625-190410.png","size":"xl","action":{"type":"uri","uri":"https://joox.com"},"flex":1}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#33ffff"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"vertical"}],"type":"box","spacing":"xs","layout":"vertical"},"footer":{"type":"box","layout":"horizontal","contents":[{"type":"text","text":"Creator","size":"xxs","wrap":True,"weight":"bold","color":"#ffffff","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"align":"center"}]}},{"styles":{"body":{"backgroundColor":"#000000"},"footer":{"backgroundColor":"#ff0000"}},"type":"bubble","size":"micro","body":{"contents":[{"contents":[{"type":"separator","color":"#ff0000"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"text":"My profile","size":"xxs","align":"center","color":"#ffffff","wrap":True,"weight":"bold","type":"text"}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"type":"image","url":"https://obs.line-scdn.net/{}".format(client.getContact(mid).pictureStatus),"size":"full","aspectMode":"cover","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"flex":0}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"contents":[{"text":"·٠  𝕬𝖋𝖗𝖎𝖟𝖆𝖑  ➣","size":"xxs","align":"center","color":"#ffffff","wrap":True,"weight":"bold","type":"text"}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"},{"contents":[{"type":"separator","color":"#ff0000"},{"type":"image","url":"https://i.ibb.co/XWQd8rj/20190625-201419.png","size":"xl","action":{"type":"uri","uri":"https://youtube.com"},"flex":1},{"type":"image","url":"https://i.ibb.co/1sGhJdC/20190428-232658.png","size":"xl","action":{"type":"uri","uri":"line://nv/timeline"},"flex":1},{"type":"image","url":"https://i.ibb.co/Wf8bQ2Z/20190625-105354.png","size":"xl","action":{"type":"uri","uri":"line://nv/cameraRoll/multi"},"flex":1},{"type":"image","url":"https://i.ibb.co/fxWzxcR/20190428-232352.png","size":"xl","action":{"type":"uri","uri":"line://nv/settings"},"flex":1},{"type":"image","url":"https://i.ibb.co/cb7WqMS/20190428-232825.png","size":"xl","action":{"type":"uri","uri":"line://nv/profile"},"flex":1},{"contents":[{"type":"image","url":"https://i.ibb.co/7YVnNPF/20190625-190410.png","size":"xl","action":{"type":"uri","uri":"https://joox.com"},"flex":1}],"type":"box","spacing":"xs","layout":"vertical"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"horizontal"},{"type":"separator","color":"#ff0000"}],"type":"box","layout":"vertical"}],"type":"box","spacing":"xs","layout":"vertical"},"footer":{"type":"box","layout":"horizontal","contents":[{"type":"text","text":"Creator","size":"xxs","wrap":True,"weight":"bold","color":"#ffffff","action":{"type":"uri","uri":"http://line.me/ti/p/~zul.1.01"},"align":"center"}]}}],"type":"carousel"}})
                           sendflex(to, data)
#ADD STAFF
               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        client.sendMessage(msg.to,"Contact itu sudah jadi staff")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        client.sendMessage(msg.to,"Berhasil menambahkan ke staff")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        client.sendMessage(msg.to,"Berhasil menghapus dari staff")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        client.sendMessage(msg.to,"Contact itu bukan staff")
#ADD ADMIN
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        client.sendMessage(msg.to,"Contact itu sudah jadi admin")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        client.sendMessage(msg.to,"➣ Berhasil menambahkan ke admin")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        client.sendMessage(msg.to,"Berhasil menghapus dari admin")
                    else:
                        wait["delladmin"] = True
                        client.sendMessage(msg.to,"➣ Contact itu bukan admin")

#UPDATE FOTO
               if msg.contentType == 1:
                 if msg._from in admin:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = client.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            client.sendMessage(msg.to, "Berhasil menambahkan gambar")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False

               if msg.toType == 2:
                 if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = client.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     client.updateGroupPicture(msg.to, path)
                     client.sendMessage(msg.to, "Berhasil mengubah foto group")

               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["ARfoto"]:
                            path = client.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][mid]
                            client.updateProfilePicture(path)
                            client.sendMessage(msg.to,"Foto berhasil dirubah")

               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        client.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "help":
                            if msg._from in owner:
                                wait["selfbot"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "text","text":"{}".format(help),"size":"xxs","align":"center","color":"#0000CC","wrap":True,},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "HELP MESSAGE","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "  ❄  AULIA ➣","color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)
                          
                        elif cmd == "menu self":
                            if msg._from in owner:
                                wait["selfbot"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "text","text":"{}".format(menuSelf),"size":"xxs","align":"center","color":"#0000CC","wrap":True,},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "MENU SELF","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "  ❄  AULIA ➣","color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)
    
                        elif cmd == "menu admin":
                            if msg._from in owner:
                                wait["selfbot"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "text","text":"{}".format(menuAdmin),"size":"xxs","align":"center","color":"#0000CC","wrap":True,},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "MENU ADMIN","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "  ❄  AULIA ➣","color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)
                          
                        elif cmd == "media":
                            if msg._from in owner:
                                wait["selfbot"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "text","text":"{}".format(media),"size":"xxs","align":"center","color":"#0000CC","wrap":True,},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "MEDIA","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "  ❄  AULIA ➣","color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)
                          
                        elif cmd == "carousel":
                            if msg._from in owner:
                                wait["selfbot"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "text","text":"{}".format(listCarousel),"size":"xxs","align":"center","color":"#0000CC","wrap":True,},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "LIST CAROUSEL","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "  ❄  AULIA ➣","color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)
    
                        if cmd == "self on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Selfbot diaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)
                                
                        elif cmd == "self off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Selfbot dinonaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)
                                                               
                        elif cmd == "login liff":
                            if msg._from in owner:
                                wait["selfbot"] = True
                                client.sendMessage(msg.to, "Click Link for Access Template :\nline://app/1602687308-GXq4Vvk9?type=text&text=Success\n")
                                     
                        elif cmd == "Spaminvite off":
                            if msg._from in admin:
                              if settings["SpamInvite"] == False:
                                 client.sendMessage(msg.to, "➣ Send Contact to send grup Off..")            
          
                        if cmd == "unsend on":
                            if msg._from in admin:
                                wait["unsend"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "DetectUnsend diaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)
                                
                        elif cmd == "unsend off":
                            if msg._from in admin:
                                wait["unsend"] = False
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "DetectUnsend dinonaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)
                                            
                        elif cmd == "status":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "   ❄   STATUS   ➣\n\n"
                                if wait["sticker"] == True: md+="➣  Sticker  「ON」\n"
                                else: md+="➣  Sticker  「OFF」\n"
                                if wait["contact"] == True: md+="➣  Contact   「ON」\n"
                                else: md+="➣  Contact   「OFF」\n"
                                if wait["Mentionkick"] == True: md+="➣  Notag    「ON」\n"
                                else: md+="➣  Notag    「OFF」\n"
                                if wait["detectMention"] == True: md+="➣  Respon   「ON」\n"
                                else: md+="➣  Respon   「OFF」\n"
                                if wait["autoJoin"] == True: md+="➣  Autojoin 「ON」\n"
                                else: md+="➣  Autojoin 「OFF」\n"
                                if wait["autoAdd"] == True: md+="➣  Autoadd  「ON」\n"
                                else: md+="➣  Autoadd  「OFF」\n"
                                if msg.to in welcome: md+="➣  Welcome  「ON」\n"
                                else: md+="➣  Welcome  「OFF」\n"
                                if wait["autoLeave"] == True: md+="➣  Autoleave「ON」\n"
                                else: md+="➣  Autoleave「OFF」\n"
                                client.sendMessage(msg.to, md+"\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif ("Mid " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = client.getContact(key1)
                               client.sendMessage(msg.to, "Nama : "+str(mi.displayName)+"\nMID : " +key1)

                        elif text.lower() == "hapus chat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   client.removeAllMessages(op.param2)
                                   contact = client.getContact(sender)
                                   data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Sudah bersih boss","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                   sendTemplate(to, data)
                               except:
                                   pass

                        elif cmd.startswith("bcast: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = client.getGroupIdsJoined()
                               for group in saya:
                                   client.sendMessage(group,"❄   Broadcast   ➣\n" + str(pesan))

                        elif cmd.startswith("footer "):
                            khie = text.split(" ")
                            hey = text.replace(khie[0] + " ", "")
                            text = "{}".format(hey)
                            data = {
                                "type": "text",
                                "text": "{}".format(text),
                                "sentBy": {
                                    "label": "{}".format(client.getContact(mid).displayName),
                                    "iconUrl": "https://i.ibb.co/M7NQT5w/1625039713477.jpg",
                                    "linkUrl": "line://app/1563216514-3laRoKqK?type=foimage&img=https://i.ibb.co/M7NQT5w/1625039713477.jpg",
                                }
                            }
                            sendTemplate(to, data)
                            
                        elif cmd.startswith("flex "):
                            sep = text.split(" ")
                            pesan = text.replace(sep[0] + " ","")
                            data = {
                                "type": "flex",
                                "altText": "flex",
                                "contents": {
                                    "type": "bubble",
                                    "body": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "{}".format(pesan),
                                                "wrap": True,
                                                "align": "start",
                                                "gravity": "center",
                                                "size": "sm"
                                            },
                                        ]
                                    }
                                }
                            }
                            sendTemplate(to, data)
                            
                        elif cmd == "nmBots":
                            dataProfile = [
                                {
                                    "type": "bubble",
                                    "styles": {
                                        "header": {"backgroundColor": "#000000"},
                                    },
                                    "header": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "contents": [
                                                    {
                                                    "url": "https://i.ibb.co/M7NQT5w/1625039713477.jpg",
                                                    "type": "image",
                                                    "size": "full"
                                                },
                                            ],
                                                "type": "box",
                                                "spacing": "sm",
                                                "layout": "vertical"
                                            },
                                        ]
                                    }
                                }
                            ]
                            data = {
                                "type": "flex",
                                "altText": "Message",
                                "contents": {
                                    "type": "carousel",
                                    "contents": dataProfile
                                }
                            }
                            sendTemplate(to, data)
                                            
                        elif cmd.startswith("smule "):
                                query = cmd.replace("smule ","")
                                b = urllib.parse.quote(query)
                                puy.sendMessage(to,"Searching to id smule..")
                                client.sendMessage(to, "Nama : "+b+"\nId smule : http://smule.com/"+query)                  

                        if cmd.startswith("youtube:  "):
                            a = client.requestweb("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=25&q=")
                            if a["items"] != []:
                                no = 0
                                ret_ = []
                                for music in a["items"]:
                                    no += 1
                                    ret_.append({"type": "bubble","header": {"type": "box","layout": "horizontal","contents": [{"type": "text","text": "Youtube","weight": "bold","color": "#9b0606","size": "sm"}]},"hero": {"type": "image","url": 'https://i.ytimg.com/vi/{}/hqdefault.jpg'.format(music['id']['videoId']),"size": "full","aspectRatio": "20:13","aspectMode": "cover","action": {"type": "uri","uri": 'https://www.youtube.com/watch?v=' +music['id']['videoId']}},"body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","margin": "lg","spacing": "sm","contents": [{"type": "box","layout": "baseline","spacing": "sm","contents": [{"type": "text","text": "Title","color": "#9b0606","size": "sm","flex": 1},{"type": "text","text": "{}".format(music['snippet']['title']),"color": "#262423","wrap": True,"size": "sm","flex": 5}]}]}]},"footer": {"type": "box","layout": "horizontal","spacing": "sm","contents": [{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "youtube","uri": 'https://www.youtube.com/watch?v=' +music['id']['videoId']}},{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "Music","uri": "{}youtube%20video%20https://www.youtube.com/watch?v={}".format(wait['ttt'],music['id']['videoId'])}},{"type": "button","style": "link","height": "sm","action": {"type": "uri","label": "creator","uri": "{}youtube%20audio%20https://www.youtube.com/watch?v={}".format(wait['ttt'],music['id']['videoId'])}},],}})
                                k = len(ret_)//10
                                for aa in range(k+1):
                                    data = {"messages": [{"type": "flex","altText": "Youtube.","contents": {"type": "carousel","contents": ret_[aa*10 : (aa+1)*10]}}]}
                                    sendCarousel(to,data)
                            else:
                                client.sendMessage(to,"ERROR")
                                
                        elif cmd.startswith("music: "):
                           if msg._from in admin:
                              sep = msg.text.split(" ")
                              search = msg.text.replace(sep[0] + " ","")
                              params = {'songname': search}
                              with requests.session() as web:
                                  web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                  r = web.get("https://ide.fdlrcn.com/workspace/yumi-apis/joox?".format(urllib.parse.urlencode(params)))
                                  try:
                                      data = json.loads(r.text)
                                      for song in data:
                                          ret_ = "╔══[ Music ]"
                                          ret_ += "\n╠ Nama lagu : {}".format(str(song[0]))
                                          ret_ += "\n╠ Durasi : {}".format(str(song[1]))
                                          ret_ += "\n╠ Link : {}".format(str(song[3]))
                                          ret_ += "\n╚══[ Waiting Audio ]"
                                      client.sendMessage(msg.to, str(ret_))
                                      client.sendMessage(msg.to, "Mohon bersabar musicnya lagi di upload")
                                      client.sendAudioWithURL(msg.to, song[3])
                                  except:
                                      client.sendMessage(to, "Musik tidak ditemukan")

                        elif text.lower() == "mykey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               client.sendMessage(msg.to, "「Mykey」\nSetkey bot mu「 " + str(Setmain["keyCommand"]) + " 」")
                               
                        elif cmd.startswith("setkey "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   client.sendMessage(msg.to, "Gagal mengganti key")
                               else:
                                   Setmain["keyCommand"] = str(key).lower()
                                   client.sendMessage(msg.to, "「Setkey」\nSetkey diganti jadi「{}」".format(str(key).lower()))

                        elif text.lower() == "resetkey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               Setmain["keyCommand"] = ""
                               client.sendMessage(msg.to, "「Setkey」\nSetkey mu kembali ke awal")

                        elif cmd == "restart":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               client.sendMessage(msg.to, "➣   prosess...")
                               Setmain["restartPoint"] = msg.to
                               restartBot()
                               contact = client.getContact(sender)
                               data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Restart Success","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                               sendTemplate(to, data)
                            
                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "Aktif " +waktu(eltime)
                               client.sendMessage(msg.to,bot)
                            
                        elif cmd.startswith("infogrup "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = client.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = client.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(client.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "➣ Fams Grup Info\n"
                                ret_ += "\n➣Nama Group : {}".format(G.name)
                                ret_ += "\n➣ID Group : {}".format(G.id)
                                ret_ += "\n➣Pembuat : {}".format(gCreator)
                                ret_ += "\n➣Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n➣Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n➣Jumlah Pending : {}".format(gPending)
                                ret_ += "\n➣Group Qr : {}".format(gQr)
                                ret_ += "\n➣Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                client.sendMessage(to, str(ret_))
                            except:
                                pass

                        elif cmd == "gruplist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = client.getGroupIdsJoined()
                               for i in gid:
                                   G = client.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               client.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "open":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = client.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   client.updateGroup(X)
                                   contact = client.getContact(sender)
                                   data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Url Opened","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                   sendTemplate(to, data)

                        elif cmd == "close":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = client.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   client.updateGroup(X)
                                   contact = client.getContact(sender)
                                   data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Url Closed","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                   sendTemplate(to, data)

                        elif cmd == "url grup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = client.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      client.updateGroup(x)
                                   gurl = client.reissueGroupTicket(msg.to)
                                   client.sendMessage(msg.to, "Nama : "+str(x.name)+ "\nUrl grup : http://line.me/R/ti/g/"+gurl)

#===========UPDATE============#
                        elif cmd == "updategrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Kirim fhoto yg kece","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "updatefoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["ARfoto"][mid] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Kirim fhoto yg kece","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)
                                
                        elif cmd.startswith("myname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = client.getProfile()
                                profile.displayName = string
                                client.updateProfile(profile)
                                client.sendMessage(msg.to,"➣ Nama diganti jadi " + string + "")

                        elif cmd == "tagall" or text.lower() == 'tag':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               group = client.getGroup(msg.to)
                               nama = [contact.mid for contact in group.members]
                               nm1, nm2, nm3, nm4,nm5,nm6,nm7, jml = [], [], [], [],[], [], [], len(nama)
                               if jml <= 20:
                                   mentionMembers(msg.to, nama)
                               if jml > 20 and jml < 40:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, len(nama)-1):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                               if jml > 40 and jml < 60:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, len(nama)-1):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                               if jml > 60 and jml < 80:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, len(nama)-1):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                               if jml > 80 and jml < 100:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, len(nama)-1):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                               if jml > 100 and jml < 120:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, len(nama)-1):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                               if jml > 120 and jml < 140:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, 119):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                                   for o in range (120, len(nama)-1):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7)
                               if jml > 140 and jml < 160:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, 119):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                                   for o in range (120, 139):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7)
                                   for p in range (140, len(nama)-1):
                                       nm8 += [nama[p]]
                                   mentionMembers(msg.to, nm8)

                        elif cmd == "listadmin":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                a = 0
                                b = 0
                                c = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +client.getContact(m_id).displayName + "\n"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +client.getContact(m_id).displayName + "\n"
                                for m_id in staff:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +client.getContact(m_id).displayName + "\n"
                                client.sendMessage(msg.to,"➣ List Admin\n\n➣ Super admin:\n"+ma+"\n➣ Admin:\n"+mb+"\n➣ Staff:\n"+mc+"\nTotal「%s」 Dpk" %(str(len(owner)+len(admin)+len(staff))))

                        elif cmd == "pamit":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = client.getGroup(msg.to)
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Message".format(client.getContact(mid).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "  Bye - bye","size": "xxs","color": "#000000","weight": "bold","align": "center",}],},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#FF0000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],}}]}}                                  
                                sendTemplate(to, data)
                                client.leaveGroup(msg.to)

                        elif cmd == "sprespon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                get_profile_time_start = time.time()
                                get_profile = client.getProfile()
                                get_profile_time = time.time() - get_profile_time_start
                                get_group_time_start = time.time()
                                get_group = client.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                get_contact_time_start = time.time()
                                get_contact = client.getContact(mid)
                                get_contact_time = time.time() - get_contact_time_start
                                client.sendMessage(msg.to, "➣ Speed respon\n\n - Get Profile\n   %.10f\n - Get Contact\n   %.10f\n - Get Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))

                        elif cmd == "lurking on":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 Setmain['ARreadPoint'][msg.to] = msg_id
                                 Setmain['ARreadMember'][msg.to] = {}
                                 client.sendMessage(msg.to, "➣ Lurking berhasil diaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                            
                        elif cmd == "lurking off":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 del Setmain['ARreadPoint'][msg.to]
                                 del Setmain['ARreadMember'][msg.to]
                                 client.sendMessage(msg.to, "➣ Lurking berhasil dinoaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                            
                        elif cmd == "lurkers":
                          if msg._from in admin:
                            if msg.to in Setmain['ARreadPoint']:
                                if Setmain['ARreadMember'][msg.to] != {}:
                                    aa = []
                                    for x in Setmain['ARreadMember'][msg.to]:
                                        aa.append(x)
                                    try:
                                        arrData = ""
                                        textx = "  [ Result {} member ]    \n\n  [ Lurkers ]\n1. ".format(str(len(aa)))
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            tz = pytz.timezone("Asia/Jakarta")
                                            timeNow = datetime.now(tz=tz)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += str(b) + ". "
                                            else:
                                                try:
                                                    no = "[ {} ]".format(str(client.getGroup(msg.to).name))
                                                except:
                                                    no = "  "
                                        msg.to = msg.to
                                        msg.text = textx+"\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        client.sendMessage(msg)
                                    except:
                                        pass
                                    try:
                                        del Setmain['ARreadPoint'][msg.to]
                                        del Setmain['ARreadMember'][msg.to]
                                    except:
                                        pass
                                    Setmain['ARreadPoint'][msg.to] = msg.id
                                    Setmain['ARreadMember'][msg.to] = {}
                                else:
                                    client.sendMessage(msg.to, "User kosong...")
                            else:
                                client.sendMessage(msg.to, "Ketik lurking on dulu")

                        elif cmd == "sider on":
                                pro["prosider"][msg.to]=True
                                with open('pro.json', 'w') as fp:
                                    json.dump(pro, fp, sort_keys=True, indent=4)
                                contact = client.getContact(mid)
                                data = {"type": "flex","altText": "{} Bagi2 Sembako".format(client.getContact(mid).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Cek Sider diaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(mid).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)
                                try:
                                    del ciduk['ceadPoint'][msg.to]
                                    del ciduk['ceadMember'][msg.to]
                                except:
                                    pass
                                now2 = datetime.now()
                                ciduk['ceadPoint'][msg.to] = msg.id
                                ciduk['ceadMember'][msg.to] = ""
                                ciduk['cetTime'][msg.to] = datetime.now().strftime('%Y-%m-%d %H:%M')
                                ciduk['cOM'][msg.to] = {}
                        elif cmd == "sider off":
                                del pro["prosider"][msg.to]
                                with open('pro.json', 'w') as fp:
                                    json.dump(pro, fp, sort_keys=True, indent=4)
                                contact = client.getContact(mid)
                                data = {"type": "flex","altText": "{} Bagi2 Sembako".format(client.getContact(mid).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Cek Sider dinonaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(mid).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)
                                
#===========Hiburan============#
                        elif cmd.startswith("get-audio "):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            query = msg.text.replace(sep[0] + " "," ")
                            cond = query.split("|")
                            search = str(cond[0])
                            with requests.session() as web:
                                web.headers["User-Agent"] = "Mozilla/5.0"
                                result = web.get("https://farzain.xyz/api/premium/yt_search.php?apikey=apikey_saintsbot&id={}".format(str(search)))
                                data = result.text
                                data = json.loads(data)
                                if len(cond) == 1:
                                    if data["respons"] != []:
                                        num = 0
                                        ret_ = "「 Pencarian Audio 」\n"
                                        for res in data["respons"]:
                                            num += 1
                                            ret_ += "\n {}. {}".format(str(num), str(res['title']))
                                        ret_ += "\n\n Total {} Result".format(str(len(data["respons"])))
                                        client.sendMessage(msg.to, str(ret_))
                                        client.sendText(to, "Ketik Get-audio {} | angka\nuntuk melihat detail lagu".format(str(search)))
                                if len(cond) == 2:
                                    num = int(cond[1])
                                    if num <= len(data["respons"]):
                                        res = data["respons"][num - 1]
                                        with requests.session() as web:
                                            web.headers["User-Agent"] = "Mozilla/5.0"
                                            result = web.get("http://rahandiapi.herokuapp.com/youtubeapi?key=betakey&q=https://www.youtube.com/watch?v={}".format(str(res['video_id'])))
                                            data = result.text
                                            data = json.loads(data)
                                            ret_ = "「 Detail Lagu 」\nTitle : "+data['result']['title']
                                            ret_ += "\nLikes : "+str(data['result']['likes'])
                                            ret_ += "\nDislikes : "+str(data['result']['dislikes'])
                                            ret_ += "\nDuration : "+str(data['result']['duration'])
                                            ret_ += "\nRating : "+str(data['result']['rating'])
                                            ret_ += "\nAuthor : "+str(data['result']['author'])+"\n"
                                            cover = data['result']['thumbnail']
                                            if data["result"]["audiolist"] != []:
                                                for koplok in data["result"]["audiolist"]:
                                                    ret_ += "\nType : "+koplok['extension']
                                                    ret_ += "\nResolusi : "+koplok['resolution']
                                                    ret_ += "\nSize : "+koplok['size']
                                                    ret_ += "\nLink : "+koplok['url']
                                                    if koplok['resolution'] == '50k':
                                                        audio = koplok['url']
                                            client.sendImageWithURL(msg.to,cover)
                                            client.sendMessage(msg.to, str(ret_))
                                            client.sendAudioWithURL(msg.to,audio)

                        elif cmd.startswith("spamcall: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                client.sendMessage(msg.to,"➣ Total Spamcall Diubah Menjadi " +strnum)

                        elif cmd.startswith("spamtag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Setmain["ARlimit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                client.sendMessage(msg)
                                            except Exception as e:
                                                client.sendMessage(msg.to,str(e))
                                    else:
                                        client.sendMessage(msg.to,"➣ Jumlah melebihi 1000")
                                        
                        elif cmd == "spamcall":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                             if msg.toType == 2:
                                group = client.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(wait["limit"])
                                client.sendMessage(msg.to, "➣ Berhasil mengundang {} undangan Call Grup".format(str(wait["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                        call.acquireGroupCallRoute(to)
                                        call.inviteIntoGroupCall(to, contactIds=members)
                                     except Exception as e:
                                        client.sendMessage(msg.to,str(e))
                                else:
                                    client.sendMessage(msg.to,"➣ Jumlah melebihi batas")

                        elif cmd.startswith(".run "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                cust = cmd.split(".run ")[1]
                                os.system('nohup python3 %s.py &'%cust)
                                client.sendMessage(msg.to, "Running {} Success".format(cust))
                                
                        elif cmd.startswith("s"):
                            dan = text.split("|")
                            nam = dan[1]
                            jlh = int(dan[2])
                            target = dan[3]
                            grr = client.groups
                            client.findAndAddContactsByMid(target)
                            if jlh <= 1000:
                                for var in range(20,jlh):
                                    gcr = client.createGroup(nam, [target])
                                    Thread(target=client.inviteIntoGroup,args=(gcr.id, [target]),).start()
                                    time.sleep(2)
                                    client.leaveGroup(gcr.id)
                                client.sendMention(to, "➣ Succesfully Spam Invite @! to Group {}".format(gcr.name), [target])
                                
                        elif cmd.startswith("ss"):
                            key = eval(msg.contentMetadata["MENTION"])
                            target = key["MENTIONEES"][0]["M"]
                            dan = text.split("|")
                            nam = dan[1]
                            jlh = int(dan[2])
                            grr = client.groups
                            client.findAndAddContactsByMid(target)
                            if jlh <= 101:
                                for var in (0,jlh):
                                    gcr = client.createGroup(nam, [target])
                                    client.inviteIntoGroup(gcr.id, [target])
                                    time.sleep(2)
                                    client.leaveGroup(gcr.id)
                                client.sendMention(to, "➣ Succesfully Spam Invite @! to Group {}".format(gcr.name), [target])

                        elif 'Gift: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('Gift: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      client.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)

                        elif 'Spam: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('Spam: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      client.sendMessage(midd, str(Setmain["ARmessage1"]))

                        elif 'ID line: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              msgs = msg.text.replace('ID line: ','')
                              conn = client.findContactsByUserid(msgs)
                              if True:
                                  client.sendMessage(msg.to, "http://line.me/ti/p/~" + msgs)
                                  client.sendMessage(msg.to, None, contentMetadata={'mid': conn.mid}, contentType=13)

#===========Protection============#
                        elif 'Welcome ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "➣ Welcome Msg sudah aktif"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = client.getGroup(msg.to)
                                       msgs = "➣ Welcome Msg diaktifkan\nDi Group : " +str(ginfo.name)
                                  client.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = client.getGroup(msg.to)
                                         msgs = "➣ Welcome Msg dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "➣ Welcome Msg sudah tidak aktif"
                                    client.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif ("Tendang " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in admin:
                                       try:
                                           client.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass
                                           
                        elif ("kickall" in msg.text):
                          if msg._from in admin:
                               nk0 = msg.text.replace("kickall")
                               gs = client.getGroup(msg.to)
                               targets = []
                               for s in gs.members:
                                   if _name in s.displayName:
                                      targets.append(s.mid)
                               if targets == []:
                                   sendMessage(msg.to,"limit")
                                   pass
                               else:
                                   for target in targets:
                                        try:
                                            client.kickoutFromGroup(msg.to,[target])
                                            print (msg.to,[g.mid])
                                        except:
                                            client.sendMessage(msg.to," Kick : 1,\nCancel : 1,")

#===========ADMIN ADD============#
                        elif ("Adminadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin[target] = True
                                           f=codecs.open('admin.json','w','utf-8')
                                           json.dump(admin, f, sort_keys=True, indent=4,ensure_ascii=False)                                             
                                           client.sendMessage(msg.to,"➣ Berhasil menambahkan admin")
                                       except:
                                           pass

                        elif ("Staffadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff.append(target)
                                           client.sendMessage(msg.to,"➣  Berhasil menambahkan staff")
                                       except:
                                           pass

                        elif ("Admindell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in mid:
                                       try:
                                           admin.remove(target)
                                           client.sendMessage(msg.to,"➣ Berhasil menghapus admin")
                                       except:
                                           pass

                        elif ("Staffdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in mid:
                                       try:
                                           staff.remove(target)
                                           client.sendMessage(msg.to,"Berhasil menghapus admin")
                                       except:
                                           pass

                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                            if msg._from in admin:
                                wait["addadmin"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Kirim Contact nya","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "admin:repeat" or text.lower() == 'admin:repeat':
                            if msg._from in admin:
                                wait["delladmin"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Kirim Contact nya","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "staff:on" or text.lower() == 'staff:on':
                            if msg._from in admin:
                                wait["addstaff"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Kirim Contact nya","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "staff:repeat" or text.lower() == 'staff:repeat':
                            if msg._from in admin:
                                wait["dellstaff"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Kirim Contact nya","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "refresh" or text.lower() == 'refresh':
                            if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(mid).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Refresh Berhasil","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "contact admin" or text.lower() == 'contact admin':
                            if msg._from in admin:
                                ma = ""
                                for i in admin:
                                    ma = client.getContact(i)
                                    client.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "contact staff" or text.lower() == 'contact staff':
                            if msg._from in admin:
                                ma = ""
                                for i in staff:
                                    ma = client.getContact(i)
                                    client.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

#===========COMMAND ON OFF============#
                        elif cmd == "notag on" or text.lower() == 'notag on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Notag diaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "notag off" or text.lower() == 'notag off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["MentionKick"] = False
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Notag dinonaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                client.sendMessage(msg.to,"Deteksi contact diaktifkan")

                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                client.sendMessage(msg.to,"Deteksi contact dinonaktifkan")

                        elif cmd == "respon on" or text.lower() == 'respon on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "AutoRespon diaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "respon off" or text.lower() == 'respon off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = False
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "AutoRespon dinonaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "AutoJoin diaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                contact = client.getContact(sender)
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "AutoJoin dinonaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "AutoLeave diaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "AutoLeave dinonaktifkan","color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                sendTemplate(to, data)

                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                client.sendMessage(msg.to,"Auto add diaktifkan")

                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                client.sendMessage(msg.to,"Auto add dinonaktifkan")

                        elif cmd == "read on" or text.lower() == 'autoread on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoRead"] = True
                                client.sendMessage(msg.to,"Auto raed diaktifkan")

                        elif cmd == "read off" or text.lower() == 'autoread off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoRead"] = False
                                client.sendMessage(msg.to,"Auto read dinonaktifkan")

                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = True
                                client.sendMessage(msg.to,"➣ Detect sticker diaktifkan")

                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = False
                                client.sendMessage(msg.to,"➣ Detect sticker dinonaktifkan")

                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = True
                                client.sendMessage(msg.to,"➣ Autojoin ticket diaktifkan")

                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = False
                                client.sendMessage(msg.to,"➣ Autojoin Tiket dinonaktifkan")

#===========
#===========COMMAND SET============#
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  client.sendMessage(msg.to, "Gagal mengganti Pesan Msg")
                              else:
                                  wait["message"] = spl
                                  client.sendMessage(msg.to, "「Pesan Msg」\nPesan Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  client.sendMessage(msg.to, "Gagal mengganti Welcome Msg")
                              else:
                                  wait["welcome"] = spl
                                  client.sendMessage(msg.to, "「Welcome Msg」\nWelcome Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  client.sendMessage(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag"] = spl
                                  client.sendMessage(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set spam: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set spam: ','')
                              if spl in [""," ","\n",None]:
                                  client.sendMessage(msg.to, "Gagal mengganti Spam")
                              else:
                                  Setmain["ARmessage1"] = spl
                                  client.sendMessage(msg.to, "「Spam Msg」\nSpam Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set sider: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set sider: ','')
                              if spl in [""," ","\n",None]:
                                  client.sendMessage(msg.to, "Gagal mengganti Sider Msg")
                              else:
                                  wait["mention"] = spl
                                  client.sendMessage(msg.to, "「Sider Msg」\nSider Msg diganti jadi :\n\n➣「{}」".format(str(spl)))

                        elif text.lower() == "cek pesan":
                            if msg._from in admin:
                               client.sendMessage(msg.to, "「Pesan Msg」\nPesan Msg mu :\n\n「 " + str(wait["message"]) + " 」")

                        elif text.lower() == "cek welcome":
                            if msg._from in admin:
                               client.sendMessage(msg.to, "「Welcome Msg」\nWelcome Msg mu :\n\n「 " + str(wait["welcome"]) + " 」")

                        elif text.lower() == "cek respon":
                            if msg._from in admin:
                               client.sendMessage(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag"]) + " 」")

                        elif text.lower() == "cek spam":
                            if msg._from in admin:
                               client.sendMessage(msg.to, "「Spam Msg」\nSpam Msg mu :\n\n「 " + str(Setmain["ARmessage1"]) + " 」")

                        elif text.lower() == "cek sider":
                            if msg._from in admin:
                               client.sendMessage(msg.to, "「Sider Msg」\nSider Msg mu :\n\n「 " + str(wait["mention"]) + " 」")

#===========JOIN TICKET============#
                        elif "/ti/g/" in msg.text.lower():
                          if wait["selfbot"] == True:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = client.findGroupByTicket(ticket_id)
                                     client.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     data = {"type": "flex","altText": "{} sent a Command".format(client.getContact(sender).displayName),"contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","backgroundColor": "#FFFFFF","contents": [{"type": "image","url": "https://i.ibb.co/QNFxN8N/1652366614290.jpg","size": "full","aspectMode": "cover","aspectRatio": "6:2","gravity": "top"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(group.name),"color": "#FFFFFF","align": "center","size": "xxs","offsetTop": "3px"}],"position": "absolute","cornerRadius": "5px","offsetTop": "26px","offsetStart": "3px","height": "23px","width": "150px","borderWidth": "1px","borderColor": "#000000","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "   {}".format(client.getContact(sender).displayName),"color": "#FFFFFF","size": "xxs"}],"position": "absolute","width": "100px","height": "20px","borderWidth": "1px","borderColor": "#000000","cornerRadius": "10px","offsetTop": "3px","offsetStart": "35px","backgroundColor": "#0000CC"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "hello, world"},{"type": "image","url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),"position": "absolute","align": "center","size": "full","aspectRatio": "1:1","aspectMode": "cover","backgroundColor": "#000000","action": {"type": "uri","uri": "line://nv/profilePopup/mid=ub2f270429a95cb4a3cc74055c316eb36"}}],"position": "absolute","width": "26px","height": "26px","borderWidth": "1px","borderColor": "#FF0000","cornerRadius": "15px","offsetStart": "5px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000CC","cornerRadius": "10px"}}]}}
                                     sendTemplate(to, data)
                                     
    except Exception as error:
        print (error)

while True:
    try:
        delExpire()
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                oepoll.setRevision(op.revision)
                thread1 = threading.Thread(target=bot, args=(op,))#self.OpInterrupt[op.type], args=(op,)
                thread1.start()                
                thread1.join()
    except Exception as e:
        logError(e)
